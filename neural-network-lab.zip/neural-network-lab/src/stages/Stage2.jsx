import { useState, useMemo } from 'react';
import FeedbackToast from '../components/FeedbackToast';
import { CREATURES, FEATURE_NAMES } from '../data/creatures';
import { forwardPass } from '../lib/network';

function CreatureCard({ creature, result, compact }) {
  const predicted = result ? (result.output >= 0.5 ? 'Carnivore' : 'Herbivore') : null;
  const actual = creature.target === 1 ? 'Carnivore' : 'Herbivore';
  const isCorrect = result ? predicted === actual : null;

  return (
    <div style={{
      background: 'var(--surface-2)', border: `1px solid ${isCorrect === null ? 'var(--border)' : isCorrect ? 'var(--accent)' : 'var(--danger)'}`,
      borderRadius: 4, padding: compact ? '8px 10px' : '12px 14px',
      display: 'flex', alignItems: 'center', gap: compact ? 8 : 12,
      transition: 'border-color 0.3s',
      boxShadow: isCorrect ? '0 0 8px var(--phosphor-dim)' : isCorrect === false ? '0 0 8px rgba(255,51,51,0.15)' : 'none',
    }}>
      <span style={{ fontSize: compact ? 20 : 28 }}>{creature.emoji}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: compact ? 12 : 14, fontWeight: 600, color: 'var(--text-1)', fontFamily: 'var(--font-lab)' }}>
          {creature.name}
        </div>
        {!compact && (
          <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>
            {creature.desc}
          </div>
        )}
      </div>
      {result && (
        <div style={{
          fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-mono)',
          color: isCorrect ? 'var(--accent)' : 'var(--danger)',
          textAlign: 'right',
        }}>
          <div>{predicted}</div>
          <div style={{ fontSize: 10, opacity: 0.7 }}>
            ({(result.output * 100).toFixed(0)}%)
          </div>
        </div>
      )}
      {!result && (
        <div style={{
          fontSize: 11, fontWeight: 600, fontFamily: 'var(--font-lab)',
          color: creature.target === 1 ? 'var(--warning)' : 'var(--text-3)',
          textTransform: 'uppercase', letterSpacing: '0.05em',
        }}>
          {actual}
        </div>
      )}
    </div>
  );
}

function WeightSlider({ label, value, onChange, fromLabel, toLabel }) {
  const absVal = Math.abs(value);
  const isPositive = value >= 0;

  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
        <span style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-lab)' }}>{label}</span>
        <span style={{
          fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-mono)',
          color: absVal > 0.5 ? (isPositive ? 'var(--accent)' : 'var(--danger)') : 'var(--text-3)',
        }}>
          {value > 0 ? '+' : ''}{value.toFixed(2)}
        </span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ fontSize: 9, color: 'var(--text-3)', width: 16, textAlign: 'right' }}>-1</span>
        <input
          type="range" min={-1} max={1} step={0.05}
          value={value} onChange={e => onChange(parseFloat(e.target.value))}
          style={{ flex: 1, accentColor: 'var(--accent)', height: 4, cursor: 'pointer' }}
        />
        <span style={{ fontSize: 9, color: 'var(--text-3)', width: 16 }}>+1</span>
      </div>
    </div>
  );
}

export default function Stage2({ onComplete }) {
  // Simple network: 4 inputs → 2 hidden → 1 output
  // Students adjust weights manually
  const [weightsIH, setWeightsIH] = useState([
    [0.0, 0.0],  // teeth → h0, h1
    [0.0, 0.0],  // speed → h0, h1
    [0.0, 0.0],  // size → h0, h1
    [0.0, 0.0],  // eyes → h0, h1
  ]);
  const [weightsHO, setWeightsHO] = useState([0.0, 0.0]); // h0→out, h1→out
  const [biasH] = useState([0, 0]);
  const [biasO] = useState(0);
  const [hasRun, setHasRun] = useState(false);
  const [results, setResults] = useState([]);
  const [attempts, setAttempts] = useState(0);
  const [bestScore, setBestScore] = useState(0);
  const [feedback, setFeedback] = useState({ message: '', type: '', visible: false });
  const [labNotes, setLabNotes] = useState([]);

  const runExperiment = () => {
    const res = CREATURES.map(c => {
      const { output } = forwardPass(c.inputs, weightsIH, weightsHO, biasH, biasO);
      const predicted = output >= 0.5 ? 1 : 0;
      return { ...c, output, predicted, isCorrect: predicted === c.target };
    });
    setResults(res);
    setHasRun(true);
    setAttempts(a => a + 1);

    const correct = res.filter(r => r.isCorrect).length;
    if (correct > bestScore) setBestScore(correct);

    // Generate lab note
    const wrong = res.filter(r => !r.isCorrect);
    let note = `Attempt #${attempts + 1}: ${correct}/${CREATURES.length} correct.`;
    if (wrong.length > 0) {
      const ex = wrong[0];
      const expected = ex.target === 1 ? 'Carnivore' : 'Herbivore';
      note += ` Misclassified ${ex.name} — predicted ${ex.predicted === 1 ? 'Carnivore' : 'Herbivore'}, actually ${expected}.`;
      if (ex.target === 1 && ex.predicted === 0) {
        note += ' Try increasing weights for teeth or eye position.';
      } else if (ex.target === 0 && ex.predicted === 1) {
        note += ' Some features might be misleading — size doesn\'t always indicate a predator.';
      }
    }
    setLabNotes(prev => [note, ...prev].slice(0, 5));

    if (correct >= 7) {
      setFeedback({ message: `${correct}/8 correct! ${correct === 8 ? 'Perfect classification!' : 'Almost there!'}`, type: 'correct', visible: true });
    } else if (correct >= 5) {
      setFeedback({ message: `${correct}/8 — getting warmer! Adjust your weights.`, type: 'info', visible: true });
    } else {
      setFeedback({ message: `${correct}/8 — keep experimenting! Read the lab notes.`, type: 'wrong', visible: true });
    }
    setTimeout(() => setFeedback(f => ({ ...f, visible: false })), 3500);
  };

  const updateWeightIH = (i, h) => (val) => {
    setWeightsIH(prev => {
      const copy = prev.map(r => [...r]);
      copy[i][h] = val;
      return copy;
    });
  };

  const updateWeightHO = (h) => (val) => {
    setWeightsHO(prev => {
      const copy = [...prev];
      copy[h] = val;
      return copy;
    });
  };

  const points = bestScore >= 8 ? 35 : bestScore >= 7 ? 25 : bestScore >= 5 ? 15 : 5;
  const canProceed = bestScore >= 5;

  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <h2 style={st.title}>🧬 Experiment 02: Build-a-Brain</h2>
        <p style={st.desc}>
          Build a neural network that classifies creatures as <strong style={{ color: 'var(--warning)' }}>Carnivores</strong> or{' '}
          <strong style={{ color: 'var(--text-2)' }}>Herbivores</strong>. Adjust the connection weights, then run your experiment
          to see how many it classifies correctly.
        </p>
      </div>

      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        {/* Left: Weight controls */}
        <div style={{ ...st.card, flex: '1 1 340px', minWidth: 300 }}>
          <div style={st.labNote}>NETWORK WEIGHTS</div>

          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: 'var(--accent)', fontFamily: 'var(--font-lab)', marginBottom: 8, textTransform: 'uppercase' }}>
              Input → Hidden Node A
            </div>
            {FEATURE_NAMES.map((name, i) => (
              <WeightSlider
                key={`ih-a-${i}`}
                label={`${name} → A`}
                value={weightsIH[i][0]}
                onChange={updateWeightIH(i, 0)}
              />
            ))}
          </div>

          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: 'var(--accent)', fontFamily: 'var(--font-lab)', marginBottom: 8, textTransform: 'uppercase' }}>
              Input → Hidden Node B
            </div>
            {FEATURE_NAMES.map((name, i) => (
              <WeightSlider
                key={`ih-b-${i}`}
                label={`${name} → B`}
                value={weightsIH[i][1]}
                onChange={updateWeightIH(i, 1)}
              />
            ))}
          </div>

          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: 'var(--accent)', fontFamily: 'var(--font-lab)', marginBottom: 8, textTransform: 'uppercase' }}>
              Hidden → Output
            </div>
            <WeightSlider label="Node A → Output" value={weightsHO[0]} onChange={updateWeightHO(0)} />
            <WeightSlider label="Node B → Output" value={weightsHO[1]} onChange={updateWeightHO(1)} />
          </div>

          <div style={{ textAlign: 'center' }}>
            <button onClick={runExperiment} style={st.btn}>
              ⚡ Run Experiment
            </button>
          </div>
        </div>

        {/* Right: Results */}
        <div style={{ flex: '1 1 340px', minWidth: 300, display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Creatures */}
          <div style={{ ...st.card }}>
            <div style={st.labNote}>
              TEST SUBJECTS
              {hasRun && (
                <span style={{ float: 'right', color: bestScore >= 7 ? 'var(--accent)' : 'var(--warning)', fontFamily: 'var(--font-mono)' }}>
                  Best: {bestScore}/8
                </span>
              )}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {CREATURES.map(c => {
                const res = results.find(r => r.id === c.id);
                return <CreatureCard key={c.id} creature={c} result={res} compact />;
              })}
            </div>
          </div>

          {/* Lab notes */}
          {labNotes.length > 0 && (
            <div style={{ ...st.card }}>
              <div style={st.labNote}>LAB NOTES</div>
              {labNotes.map((note, i) => (
                <div key={i} style={{
                  fontSize: 12, color: i === 0 ? 'var(--text-1)' : 'var(--text-3)',
                  fontFamily: 'var(--font-lab)', lineHeight: 1.5,
                  marginBottom: 6, paddingBottom: 6,
                  borderBottom: i < labNotes.length - 1 ? '1px solid var(--border)' : 'none',
                }}>
                  {note}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Hint */}
      {attempts >= 2 && bestScore < 5 && (
        <div style={{ ...st.card, marginTop: 12, background: 'rgba(57,255,20,0.03)' }}>
          <div style={st.labNote}>💡 HINT</div>
          <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>
            Think about which features PREDATORS have: sharp teeth and front-facing eyes.
            Try making those weights strongly positive (+0.8 or higher) for Node A,
            and connect Node A strongly to the output. Size and speed are trickier — there are fast herbivores and large herbivores!
          </p>
        </div>
      )}

      {/* Proceed */}
      {canProceed && (
        <div style={{ textAlign: 'center', marginTop: 20 }}>
          <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 10 }}>
            {bestScore === 8 ? 'Perfect score! Your brain works flawlessly.' :
             bestScore >= 7 ? 'Excellent — your brain is nearly perfect.' :
             'Good enough to proceed — but can you do better?'}
          </p>
          <button onClick={() => onComplete(points)} style={st.btn}>
            Proceed → Experiment 03 ({points} pts earned)
          </button>
        </div>
      )}

      <FeedbackToast {...feedback} />
    </div>
  );
}

const st = {
  title: { fontSize: 24, fontWeight: 700, marginBottom: 8, fontFamily: 'var(--font-lab)' },
  desc: { fontSize: 15, color: 'var(--text-2)', lineHeight: 1.6, maxWidth: 700 },
  card: {
    background: 'var(--surface)', borderRadius: 4, border: '1px solid var(--border)',
    padding: 18, backgroundImage: 'linear-gradient(var(--grid-line) 1px, transparent 1px), linear-gradient(90deg, var(--grid-line) 1px, transparent 1px)',
    backgroundSize: '20px 20px',
  },
  labNote: {
    fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-lab)', color: 'var(--accent)',
    textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 12,
    textShadow: '0 0 8px var(--phosphor-dim)',
  },
  btn: {
    background: 'var(--surface-2)', color: 'var(--accent)', border: '1px solid var(--accent)',
    borderRadius: 4, padding: '10px 24px', fontSize: 14, fontWeight: 700,
    fontFamily: 'var(--font-lab)', cursor: 'pointer', letterSpacing: '0.03em',
    boxShadow: '0 0 12px var(--phosphor-dim)', textTransform: 'uppercase',
  },
};
